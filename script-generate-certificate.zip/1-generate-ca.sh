# This creates the private CA Key
certtool --generate-privkey --outfile ca-key.pem --bits 2048

# This creates the CA cert
certtool --generate-self-signed --load-privkey ca-key.pem --outfile ca.pem --template ca.cfg
